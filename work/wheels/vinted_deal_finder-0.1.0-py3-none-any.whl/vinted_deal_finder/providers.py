from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Protocol

from pydantic import TypeAdapter, ValidationError

from .config import ProviderConfig, WatchRule
from .models import FetchResult, Listing


class ListingProvider(Protocol):
    name: str
    ready: bool

    async def fetch_latest(self, watch: WatchRule, cursor: str | None) -> FetchResult: ...


class ProviderError(RuntimeError):
    """Base error for listing-provider failures."""


class ProviderAuthorizationError(ProviderError):
    """Raised when approved provider access has not been configured."""


class FixtureListingProvider:
    name = "fixture"
    ready = True

    def __init__(self, path: Path) -> None:
        self.path = path
        self._listings = self._load(path)

    @staticmethod
    def _load(path: Path) -> list[tuple[Listing, set[str]]]:
        try:
            raw: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ProviderError(f"cannot load fixture provider data from {path}: {exc}") from exc
        if not isinstance(raw, dict) or not isinstance(raw.get("listings"), list):
            raise ProviderError("fixture data must contain a top-level 'listings' array")

        adapter = TypeAdapter(Listing)
        parsed: list[tuple[Listing, set[str]]] = []
        for index, item in enumerate(raw["listings"]):
            if not isinstance(item, dict):
                raise ProviderError(f"fixture listing at index {index} must be an object")
            listing_data = dict(item)
            watch_ids_raw = listing_data.pop("watch_ids", [])
            if not isinstance(watch_ids_raw, list) or not all(
                isinstance(watch_id, str) for watch_id in watch_ids_raw
            ):
                raise ProviderError(f"fixture listing at index {index} has invalid watch_ids")
            try:
                parsed.append((adapter.validate_python(listing_data), set(watch_ids_raw)))
            except ValidationError as exc:
                raise ProviderError(f"invalid fixture listing at index {index}: {exc}") from exc
        return parsed

    async def fetch_latest(self, watch: WatchRule, cursor: str | None) -> FetchResult:
        start = 0
        if cursor is not None:
            try:
                start = max(0, int(cursor))
            except ValueError as exc:
                raise ProviderError(f"invalid fixture cursor: {cursor!r}") from exc
        relevant = [
            listing
            for listing, watch_ids in self._listings
            if not watch_ids or watch.id in watch_ids
        ]
        return FetchResult(listings=relevant[start:], next_cursor=str(len(relevant)))


class AuthorizedVintedProvider:
    name = "authorized_vinted"
    ready = False

    async def fetch_latest(self, watch: WatchRule, cursor: str | None) -> FetchResult:
        del watch, cursor
        raise ProviderAuthorizationError(
            "live Vinted access is disabled: supply approved API documentation or another "
            "authorized listing feed before implementing this provider"
        )


def build_provider(config: ProviderConfig) -> ListingProvider:
    if config.kind == "fixture":
        return FixtureListingProvider(config.fixture_path)
    return AuthorizedVintedProvider()

