from __future__ import annotations

import unicodedata
from dataclasses import dataclass

from .config import ScoreDefaults, ScoreWeights, WatchRule
from .models import Condition, Listing

CONDITION_SCORES: dict[Condition, float] = {
    Condition.NEW_WITH_TAGS: 100.0,
    Condition.NEW_WITHOUT_TAGS: 90.0,
    Condition.VERY_GOOD: 80.0,
    Condition.GOOD: 60.0,
    Condition.SATISFACTORY: 30.0,
    Condition.UNKNOWN: 50.0,
}


@dataclass(frozen=True, slots=True)
class DealEvaluation:
    hard_filters_match: bool
    qualifies: bool
    effective_cost_huf: int | None
    discount_pct: float | None
    price_score: float | None
    condition_score: float | None
    seller_score: float | None
    final_score: float | None
    used_fallback_buyer_fee: bool
    used_fallback_shipping: bool
    reasons: tuple[str, ...]
    rejection_reasons: tuple[str, ...]


def normalize_text(value: str) -> str:
    return unicodedata.normalize("NFKC", value).casefold().strip()


def _matches_one(value: str | None, allowed: list[str]) -> bool:
    if not allowed:
        return True
    if value is None:
        return False
    normalized = normalize_text(value)
    return normalized in {normalize_text(candidate) for candidate in allowed}


def hard_filter_rejections(listing: Listing, watch: WatchRule) -> list[str]:
    rejections: list[str] = []
    haystack = normalize_text(
        " ".join(
            part
            for part in [
                listing.title,
                listing.brand,
                listing.category,
                listing.size,
            ]
            if part
        )
    )
    query_tokens = [normalize_text(token) for token in watch.query.split() if token.strip()]
    if query_tokens and not all(token in haystack for token in query_tokens):
        rejections.append("query does not match")
    missing_includes = [
        keyword for keyword in watch.include_keywords if normalize_text(keyword) not in haystack
    ]
    if missing_includes:
        rejections.append("missing required keyword(s)")
    if any(normalize_text(keyword) in haystack for keyword in watch.exclude_keywords):
        rejections.append("contains excluded keyword")
    if not _matches_one(listing.brand, watch.brands):
        rejections.append("brand does not match")
    if not _matches_one(listing.category, watch.categories):
        rejections.append("category does not match")
    if not _matches_one(listing.size, watch.sizes):
        rejections.append("size does not match")
    if watch.allowed_conditions and listing.condition not in watch.allowed_conditions:
        rejections.append("condition does not match")
    if watch.max_item_price_huf is not None and listing.item_price_huf > watch.max_item_price_huf:
        rejections.append("item price exceeds maximum")
    if listing.currency != watch.currency:
        rejections.append("currency does not match")
    return rejections


def seller_score(listing: Listing) -> float:
    if listing.seller_rating is None or listing.seller_review_count is None:
        return 50.0
    rating_score = min(max((listing.seller_rating - 3.5) / 1.5 * 100.0, 0.0), 100.0)
    confidence = min(listing.seller_review_count / 10.0, 1.0)
    return 50.0 * (1.0 - confidence) + rating_score * confidence


def evaluate_listing(
    listing: Listing,
    watch: WatchRule,
    defaults: ScoreDefaults,
) -> DealEvaluation:
    rejections = hard_filter_rejections(listing, watch)
    if rejections:
        return DealEvaluation(
            hard_filters_match=False,
            qualifies=False,
            effective_cost_huf=None,
            discount_pct=None,
            price_score=None,
            condition_score=None,
            seller_score=None,
            final_score=None,
            used_fallback_buyer_fee=False,
            used_fallback_shipping=False,
            reasons=(),
            rejection_reasons=tuple(rejections),
        )

    if (
        watch.reference_all_in_value_huf is None
        or watch.fallback_buyer_fee_huf is None
        or watch.fallback_shipping_huf is None
    ):
        raise ValueError(f"watch {watch.id!r} is incomplete and cannot be scored")

    buyer_fee = (
        listing.buyer_fee_huf
        if listing.buyer_fee_huf is not None
        else watch.fallback_buyer_fee_huf
    )
    shipping = (
        listing.shipping_huf
        if listing.shipping_huf is not None
        else watch.fallback_shipping_huf
    )
    effective_cost = listing.item_price_huf + buyer_fee + shipping
    discount = (
        100.0
        * (watch.reference_all_in_value_huf - effective_cost)
        / watch.reference_all_in_value_huf
    )
    target_discount = watch.target_discount_pct or defaults.target_discount_pct
    computed_price_score = min(max(100.0 * discount / target_discount, 0.0), 100.0)
    computed_condition_score = CONDITION_SCORES[listing.condition]
    computed_seller_score = seller_score(listing)
    weights: ScoreWeights = watch.score_weights or defaults.weights
    final_score = (
        weights.price * computed_price_score
        + weights.condition * computed_condition_score
        + weights.seller * computed_seller_score
    )
    min_discount = (
        watch.min_discount_pct
        if watch.min_discount_pct is not None
        else defaults.min_discount_pct
    )
    min_score = watch.min_score if watch.min_score is not None else defaults.min_score

    qualification_rejections: list[str] = []
    if discount < min_discount:
        qualification_rejections.append("discount is below minimum")
    if final_score < min_score:
        qualification_rejections.append("deal score is below minimum")

    seller_reason = "Seller data unavailable; neutral seller score used"
    if listing.seller_rating is not None and listing.seller_review_count is not None:
        seller_reason = (
            f"Seller rated {listing.seller_rating:.1f}/5 across "
            f"{listing.seller_review_count} review(s)"
        )
    reasons = (
        f"Effective cost is {discount:.1f}% below the configured reference value",
        f"Condition is {listing.condition.value.replace('_', ' ')}",
        seller_reason,
    )
    return DealEvaluation(
        hard_filters_match=True,
        qualifies=not qualification_rejections,
        effective_cost_huf=effective_cost,
        discount_pct=discount,
        price_score=computed_price_score,
        condition_score=computed_condition_score,
        seller_score=computed_seller_score,
        final_score=final_score,
        used_fallback_buyer_fee=listing.buyer_fee_huf is None,
        used_fallback_shipping=listing.shipping_huf is None,
        reasons=reasons,
        rejection_reasons=tuple(qualification_rejections),
    )
